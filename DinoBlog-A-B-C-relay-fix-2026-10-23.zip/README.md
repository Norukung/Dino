# DinoBlog — nearby DTN messaging

Version **3.3-media-dtn** (versionCode **16**), Room schema **9**.

DinoBlog sends text, photos, audio, and video over nearby Wi-Fi Direct encounters. Media uses the same store, carry, and forward path as text: app-private files, a shared manifest and binary chunk protocol, interrupted-transfer resume, SHA-256 verification, and message-level delivery receipts. Relay participation and the chat's direct-only choice remain available. Nearby shows Android's full Wi-Fi Direct device name separately from the DinoBlog display name when both are known.

Build with `.\build.ps1`. The debug APK is `app/build/outputs/apk/debug/app-debug.apk`. See [AUDIO_VIDEO_DTN.md](AUDIO_VIDEO_DTN.md) for media limits, migration, and three-device procedures. Earlier phases remain documented in [PHASE11_IMAGE_DTN.md](PHASE11_IMAGE_DTN.md) and the phase reports.

Android instrumentation requires an emulator or device. Wi-Fi Direct encounters and playback on physical phones require separate device testing.
